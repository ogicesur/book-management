import { createAction, props } from '@ngrx/store';
import { Book } from '../models/book';

export const AddBook = createAction('[Book] Add Book', props<{ Book: Book }>());
export const RemoveBook = createAction('[Book] remove Book', props<{ bookId: string }>());